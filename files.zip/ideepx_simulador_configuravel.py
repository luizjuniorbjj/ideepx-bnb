#!/usr/bin/env python3
"""
SIMULADOR CONFIGURÁVEL - iDeepX MLM
Sistema completo de simulação com configurações editáveis
"""

import json
import csv
import random
import statistics
from datetime import datetime
from typing import Dict, List, Tuple
from dataclasses import dataclass, field

# Importar configurações
from config_simulacao import CENARIO_ATIVO, calcular_metricas

# ============================================
# CLASSES E ESTRUTURAS
# ============================================

@dataclass
class Cliente:
    """Cliente da rede MLM"""
    id: int
    nome: str
    perfil: str
    capital: float
    upline_id: int = None
    nivel: int = 0
    indicados_diretos: List[int] = field(default_factory=list)
    ativo: bool = True

# ============================================
# GERADOR DE REDE CONFIGURÁVEL
# ============================================

class GeradorRedeConfiguravel:
    """Gera rede baseada nas configurações"""
    
    def __init__(self, config: dict):
        self.config = config
        self.total_clientes = config['total_clientes']
        self.capital_alvo = config['capital_total_alvo']
        self.clientes = []
        
        # Distribuição de perfis
        self.distribuicao = {
            'TRADER_PURO': 0.65,
            'INICIANTE': 0.15,
            'CASUAL': 0.10,
            'EMERGENTE': 0.06,
            'ESTABELECIDO': 0.03,
            'TOP_LEADER': 0.01
        }
        
    def gerar_rede(self) -> List[Cliente]:
        """Gera a rede completa"""
        
        print(f"Gerando {self.total_clientes} clientes...")
        id_counter = 1
        
        # Criar clientes por perfil
        for perfil, percentual in self.distribuicao.items():
            quantidade = int(self.total_clientes * percentual)
            
            for _ in range(quantidade):
                # Gerar capital baseado no perfil
                capital = self._gerar_capital_por_perfil(perfil)
                
                cliente = Cliente(
                    id=id_counter,
                    nome=f"{perfil}_{id_counter}",
                    perfil=perfil,
                    capital=capital
                )
                
                self.clientes.append(cliente)
                id_counter += 1
        
        # Ajustar para atingir exatamente o total de clientes
        while len(self.clientes) < self.total_clientes:
            cliente = Cliente(
                id=id_counter,
                nome=f"TRADER_PURO_{id_counter}",
                perfil='TRADER_PURO',
                capital=self._gerar_capital_por_perfil('TRADER_PURO')
            )
            self.clientes.append(cliente)
            id_counter += 1
        
        # Construir estrutura MLM
        self._construir_estrutura_mlm()
        
        # Ajustar capital total para atingir o alvo
        self._ajustar_capital_total()
        
        return self.clientes
    
    def _gerar_capital_por_perfil(self, perfil: str) -> float:
        """Gera capital baseado no perfil"""
        
        ranges = {
            'TRADER_PURO': (100, 5000),
            'INICIANTE': (100, 2000),
            'CASUAL': (200, 5000),
            'EMERGENTE': (500, 20000),
            'ESTABELECIDO': (1000, 50000),
            'TOP_LEADER': (5000, 200000)
        }
        
        min_val, max_val = ranges.get(perfil, (100, 5000))
        
        # Usar distribuição log-normal para criar variação realista
        import math
        if min_val < 1000:
            capital = random.gauss((min_val + max_val) / 2, (max_val - min_val) / 6)
        else:
            log_min = math.log(min_val)
            log_max = math.log(max_val)
            log_capital = random.uniform(log_min, log_max)
            capital = math.exp(log_capital)
        
        return max(100, min(max_val, capital))
    
    def _construir_estrutura_mlm(self):
        """Constrói estrutura de indicações"""
        
        # Definir quantas indicações cada perfil faz
        indicacoes_por_perfil = {
            'TRADER_PURO': (0, 0),
            'INICIANTE': (1, 2),
            'CASUAL': (2, 5),
            'EMERGENTE': (5, 15),
            'ESTABELECIDO': (10, 30),
            'TOP_LEADER': (20, 50)
        }
        
        # Construir indicações
        for cliente in self.clientes:
            min_ind, max_ind = indicacoes_por_perfil.get(cliente.perfil, (0, 0))
            
            if min_ind > 0:
                num_indicacoes = random.randint(min_ind, max_ind)
                
                # Limitar ao número de clientes disponíveis
                disponíveis = [c for c in self.clientes 
                             if c.id != cliente.id and c.upline_id is None]
                
                num_indicacoes = min(num_indicacoes, len(disponíveis))
                
                for _ in range(num_indicacoes):
                    if disponíveis:
                        indicado = random.choice(disponíveis)
                        indicado.upline_id = cliente.id
                        cliente.indicados_diretos.append(indicado.id)
                        disponíveis.remove(indicado)
    
    def _ajustar_capital_total(self):
        """Ajusta capital para atingir o alvo"""
        
        capital_atual = sum(c.capital for c in self.clientes)
        
        if capital_atual > 0:
            fator = self.capital_alvo / capital_atual
            
            for cliente in self.clientes:
                cliente.capital = round(cliente.capital * fator, 2)
        
        print(f"Capital ajustado para: ${sum(c.capital for c in self.clientes):,.2f}")

# ============================================
# CALCULADOR DE COMISSÕES
# ============================================

class CalculadorComissoes:
    """Calcula comissões baseadas no modelo proporcional"""
    
    def __init__(self, rede: List[Cliente], config: dict):
        self.rede = rede
        self.config = config
        self.rede_dict = {c.id: c for c in rede}
        
        # Calcular pools
        self.capital_total = sum(c.capital for c in rede)
        self.lucro_bruto = self.capital_total * config['lucro_mensal']
        self.pool_mlm = self.lucro_bruto * config['pool_mlm']
        
        # Estruturas para cálculo
        self.matriz_niveis = {}
        self.comissoes = {}
        
        # Percentuais por nível
        self.percentuais_niveis = {
            1: 0.32, 2: 0.12, 3: 0.08, 4: 0.04, 5: 0.04,
            6: 0.08, 7: 0.08, 8: 0.08, 9: 0.08, 10: 0.08
        }
    
    def calcular(self):
        """Calcula todas as comissões"""
        
        # Construir matriz de níveis
        self._construir_matriz()
        
        # Calcular capital por nível global
        capital_por_nivel = self._calcular_capital_por_nivel()
        
        # Calcular comissões individuais
        for cliente in self.rede:
            comissao_total = 0
            detalhes = {}
            
            for nivel in range(1, 11):
                ids_nivel = self.matriz_niveis.get(cliente.id, {}).get(nivel, [])
                
                if ids_nivel:
                    # Capital deste cliente no nível
                    capital_cliente = sum(self.rede_dict[id].capital for id in ids_nivel)
                    
                    # Capital total do nível
                    capital_total_nivel = capital_por_nivel.get(nivel, 1)
                    
                    if capital_total_nivel > 0:
                        proporcao = capital_cliente / capital_total_nivel
                        pool_nivel = self.pool_mlm * self.percentuais_niveis[nivel]
                        comissao_nivel = pool_nivel * proporcao
                        
                        comissao_total += comissao_nivel
                        detalhes[nivel] = {
                            'pessoas': len(ids_nivel),
                            'capital': capital_cliente,
                            'comissao': comissao_nivel
                        }
            
            self.comissoes[cliente.id] = {
                'cliente': cliente,
                'comissao_bruta': comissao_total,
                'comissao_liquida': comissao_total - (self.config['lai_mensal'] if comissao_total > 0 else 0),
                'detalhes': detalhes
            }
    
    def _construir_matriz(self):
        """Constrói matriz de níveis para cada cliente"""
        
        for cliente in self.rede:
            self.matriz_niveis[cliente.id] = {i: [] for i in range(1, 11)}
            self._adicionar_niveis(cliente.id, cliente.indicados_diretos, 1)
    
    def _adicionar_niveis(self, cliente_raiz: int, ids: List[int], nivel: int):
        """Adiciona IDs aos níveis recursivamente"""
        
        if nivel > 10 or not ids:
            return
        
        self.matriz_niveis[cliente_raiz][nivel].extend(ids)
        
        # Próximo nível
        proximos = []
        for id in ids:
            if id in self.rede_dict:
                proximos.extend(self.rede_dict[id].indicados_diretos)
        
        if proximos:
            self._adicionar_niveis(cliente_raiz, proximos, nivel + 1)
    
    def _calcular_capital_por_nivel(self) -> Dict[int, float]:
        """Calcula capital total em cada nível globalmente"""
        
        capital_por_nivel = {i: 0 for i in range(1, 11)}
        
        for dados_cliente in self.matriz_niveis.values():
            for nivel, ids in dados_cliente.items():
                for id in ids:
                    if id in self.rede_dict:
                        capital_por_nivel[nivel] += self.rede_dict[id].capital
        
        return capital_por_nivel

# ============================================
# GERADOR DE RELATÓRIO
# ============================================

class GeradorRelatorio:
    """Gera relatórios da simulação"""
    
    def __init__(self, rede: List[Cliente], comissoes: dict, config: dict):
        self.rede = rede
        self.comissoes = comissoes
        self.config = config
    
    def gerar_resumo(self):
        """Gera resumo da simulação"""
        
        print("\n" + "=" * 80)
        print(f"RESULTADO DA SIMULAÇÃO: {self.config['nome']}")
        print("=" * 80)
        
        # Estatísticas gerais
        capital_total = sum(c.capital for c in self.rede)
        lucro_bruto = capital_total * self.config['lucro_mensal']
        pool_mlm = lucro_bruto * self.config['pool_mlm']
        
        print(f"\n📊 RESUMO FINANCEIRO:")
        print(f"   Capital Total: ${capital_total:,.2f}")
        print(f"   Lucro Bruto Mensal: ${lucro_bruto:,.2f}")
        print(f"   Pool MLM: ${pool_mlm:,.2f}")
        
        # Comissões
        com_comissao = [c for c in self.comissoes.values() if c['comissao_bruta'] > 0]
        
        print(f"\n💰 DISTRIBUIÇÃO DE COMISSÕES:")
        print(f"   Clientes com comissão: {len(com_comissao)} de {len(self.rede)}")
        print(f"   Percentual ativo: {(len(com_comissao)/len(self.rede))*100:.1f}%")
        
        if com_comissao:
            valores = [c['comissao_bruta'] for c in com_comissao]
            print(f"   Comissão média: ${statistics.mean(valores):,.2f}")
            print(f"   Comissão máxima: ${max(valores):,.2f}")
            print(f"   Comissão mínima: ${min(valores):,.2f}")
        
        # Top 5
        print(f"\n🏆 TOP 5 EARNERS:")
        top_5 = sorted(self.comissoes.values(), key=lambda x: x['comissao_bruta'], reverse=True)[:5]
        
        for i, dados in enumerate(top_5, 1):
            cliente = dados['cliente']
            print(f"\n   {i}. {cliente.nome}")
            print(f"      Capital: ${cliente.capital:,.2f}")
            print(f"      Comissão: ${dados['comissao_bruta']:,.2f}")
            print(f"      ROI: {(dados['comissao_bruta']/self.config['lai_mensal']):.1f}x")
        
        # Validação
        total_distribuido = sum(c['comissao_bruta'] for c in self.comissoes.values())
        print(f"\n✅ VALIDAÇÃO:")
        print(f"   Pool MLM: ${pool_mlm:,.2f}")
        print(f"   Total Distribuído: ${total_distribuido:,.2f}")
        print(f"   Diferença: ${abs(pool_mlm - total_distribuido):,.2f}")
        
        percentual = (total_distribuido / pool_mlm) * 100 if pool_mlm > 0 else 0
        print(f"   Percentual: {percentual:.1f}%")
        
        if abs(percentual - 100) < 1:
            print("   ✅ MODELO VALIDADO - 100% distribuído!")
    
    def exportar_csv(self):
        """Exporta resultados para CSV"""
        
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        nome_cenario = self.config['nome'].replace(' ', '_').lower()
        filename = f"simulacao_{nome_cenario}_{timestamp}.csv"
        
        with open(filename, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow(['ID', 'Nome', 'Perfil', 'Capital', 'Indicados', 'Comissao', 'ROI'])
            
            for dados in self.comissoes.values():
                cliente = dados['cliente']
                roi = dados['comissao_bruta'] / self.config['lai_mensal'] if dados['comissao_bruta'] > 0 else 0
                writer.writerow([
                    cliente.id,
                    cliente.nome,
                    cliente.perfil,
                    f"${cliente.capital:.2f}",
                    len(cliente.indicados_diretos),
                    f"${dados['comissao_bruta']:.2f}",
                    f"{roi:.1f}x"
                ])
        
        print(f"\n📁 CSV exportado: {filename}")
        return filename

# ============================================
# FUNÇÃO PRINCIPAL
# ============================================

def main():
    """Executa simulação com configurações do arquivo"""
    
    print("\n" + "🎯 " * 30)
    print("SIMULADOR CONFIGURÁVEL iDeepX")
    print("🎯 " * 30)
    
    # Mostrar configuração
    metricas = calcular_metricas()
    
    print(f"\n📋 CONFIGURAÇÃO ATIVA: {CENARIO_ATIVO['nome']}")
    print("-" * 60)
    print(f"Clientes: {CENARIO_ATIVO['total_clientes']}")
    print(f"Capital Total: ${CENARIO_ATIVO['capital_total_alvo']:,.2f}")
    print(f"Capital Médio: ${metricas['capital_medio_por_cliente']:,.2f}")
    print(f"Lucro Mensal: {CENARIO_ATIVO['lucro_mensal']*100:.1f}%")
    print(f"Pool MLM: ${metricas['pool_mlm_mensal']:,.2f}/mês")
    
    # Perguntar se quer continuar
    print("\nPressione ENTER para continuar ou CTRL+C para cancelar...")
    input()
    
    # Gerar rede
    print("\n🔧 Gerando rede...")
    gerador = GeradorRedeConfiguravel(CENARIO_ATIVO)
    rede = gerador.gerar_rede()
    
    # Calcular comissões
    print("\n💰 Calculando comissões...")
    calculador = CalculadorComissoes(rede, CENARIO_ATIVO)
    calculador.calcular()
    
    # Gerar relatório
    print("\n📊 Gerando relatório...")
    relatorio = GeradorRelatorio(rede, calculador.comissoes, CENARIO_ATIVO)
    relatorio.gerar_resumo()
    arquivo = relatorio.exportar_csv()
    
    print("\n" + "=" * 80)
    print("✅ SIMULAÇÃO COMPLETA!")
    print("=" * 80)
    print(f"""
    Para testar outro cenário:
    1. Edite o arquivo: config_simulacao.py
    2. Escolha ou crie um cenário
    3. Execute novamente: python ideepx_simulador_configuravel.py
    
    Arquivo de resultados: {arquivo}
    """)

if __name__ == "__main__":
    main()
