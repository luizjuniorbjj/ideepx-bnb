"""
🎯 ARQUIVO DE CONFIGURAÇÃO - SIMULADOR iDeepX
============================================
EDITE OS VALORES ABAIXO PARA SIMULAR DIFERENTES CENÁRIOS
"""

# ============================================
# 📊 CENÁRIOS PRÉ-DEFINIDOS
# ============================================
# Descomente o cenário que deseja usar ou crie o seu próprio

# ---- CENÁRIO 1: INÍCIO PEQUENO E REALISTA ----
CENARIO_ATIVO = {
    "nome": "Início Pequeno Realista",
    "total_clientes": 50,
    "capital_total_alvo": 100000,  # 100 mil USD
    "lucro_mensal": 0.15,          # 15% ao mês
    "pool_mlm": 0.25,              # 25% do lucro para MLM
    "lai_mensal": 19               # $19/mês
}

# ---- CENÁRIO 2: CRESCIMENTO INICIAL ----
# CENARIO_ATIVO = {
#     "nome": "Crescimento Inicial",
#     "total_clientes": 100,
#     "capital_total_alvo": 250000,  # 250 mil USD
#     "lucro_mensal": 0.15,
#     "pool_mlm": 0.25,
#     "lai_mensal": 19
# }

# ---- CENÁRIO 3: REDE MÉDIA ----
# CENARIO_ATIVO = {
#     "nome": "Rede Média",
#     "total_clientes": 300,
#     "capital_total_alvo": 600000,  # 600 mil USD
#     "lucro_mensal": 0.15,
#     "pool_mlm": 0.25,
#     "lai_mensal": 19
# }

# ---- CENÁRIO 4: REDE ESTABELECIDA ----
# CENARIO_ATIVO = {
#     "nome": "Rede Estabelecida",
#     "total_clientes": 500,
#     "capital_total_alvo": 1000000,  # 1 milhão USD
#     "lucro_mensal": 0.15,
#     "pool_mlm": 0.25,
#     "lai_mensal": 19
# }

# ---- CENÁRIO 5: GRANDE ESCALA ----
# CENARIO_ATIVO = {
#     "nome": "Grande Escala",
#     "total_clientes": 1000,
#     "capital_total_alvo": 2000000,  # 2 milhões USD
#     "lucro_mensal": 0.15,
#     "pool_mlm": 0.25,
#     "lai_mensal": 19
# }

# ---- CENÁRIO 6: MEGA REDE ----
# CENARIO_ATIVO = {
#     "nome": "Mega Rede",
#     "total_clientes": 5000,
#     "capital_total_alvo": 10000000,  # 10 milhões USD
#     "lucro_mensal": 0.15,
#     "pool_mlm": 0.25,
#     "lai_mensal": 19
# }

# ---- CENÁRIO 7: TESTE CONSERVADOR ----
# CENARIO_ATIVO = {
#     "nome": "Teste Conservador",
#     "total_clientes": 200,
#     "capital_total_alvo": 300000,  # 300 mil USD
#     "lucro_mensal": 0.10,          # 10% ao mês (conservador)
#     "pool_mlm": 0.25,
#     "lai_mensal": 19
# }

# ---- CENÁRIO 8: TESTE AGRESSIVO ----
# CENARIO_ATIVO = {
#     "nome": "Teste Agressivo",
#     "total_clientes": 200,
#     "capital_total_alvo": 500000,  # 500 mil USD
#     "lucro_mensal": 0.20,          # 20% ao mês (agressivo)
#     "pool_mlm": 0.25,
#     "lai_mensal": 19
# }

# ============================================
# 🎯 CENÁRIO CUSTOMIZADO
# ============================================
# Crie seu próprio cenário aqui:

# CENARIO_ATIVO = {
#     "nome": "Meu Cenário Custom",
#     "total_clientes": 150,        # Quantos clientes?
#     "capital_total_alvo": 350000, # Quanto de capital total?
#     "lucro_mensal": 0.12,         # Qual % de lucro mensal?
#     "pool_mlm": 0.25,             # Quanto vai para MLM?
#     "lai_mensal": 19              # Valor da licença mensal
# }

# ============================================
# 📈 CÁLCULOS AUTOMÁTICOS
# ============================================
# Estes valores são calculados automaticamente

def calcular_metricas():
    """Calcula métricas baseadas no cenário ativo"""
    
    capital_medio = CENARIO_ATIVO["capital_total_alvo"] / CENARIO_ATIVO["total_clientes"]
    lucro_bruto_mensal = CENARIO_ATIVO["capital_total_alvo"] * CENARIO_ATIVO["lucro_mensal"]
    pool_mlm_mensal = lucro_bruto_mensal * CENARIO_ATIVO["pool_mlm"]
    
    return {
        "capital_medio_por_cliente": capital_medio,
        "lucro_bruto_mensal": lucro_bruto_mensal,
        "pool_mlm_mensal": pool_mlm_mensal,
        "pool_por_nivel": {
            1: pool_mlm_mensal * 0.32,
            2: pool_mlm_mensal * 0.12,
            3: pool_mlm_mensal * 0.08,
            4: pool_mlm_mensal * 0.04,
            5: pool_mlm_mensal * 0.04,
            6: pool_mlm_mensal * 0.08,
            7: pool_mlm_mensal * 0.08,
            8: pool_mlm_mensal * 0.08,
            9: pool_mlm_mensal * 0.08,
            10: pool_mlm_mensal * 0.08
        }
    }

# ============================================
# 📊 RESUMO DO CENÁRIO ATIVO
# ============================================

if __name__ == "__main__":
    metricas = calcular_metricas()
    
    print("=" * 60)
    print(f"CENÁRIO ATIVO: {CENARIO_ATIVO['nome']}")
    print("=" * 60)
    print(f"Total de clientes: {CENARIO_ATIVO['total_clientes']}")
    print(f"Capital total: ${CENARIO_ATIVO['capital_total_alvo']:,.2f}")
    print(f"Capital médio/cliente: ${metricas['capital_medio_por_cliente']:,.2f}")
    print(f"Lucro mensal: {CENARIO_ATIVO['lucro_mensal']*100:.1f}%")
    print(f"Lucro bruto mensal: ${metricas['lucro_bruto_mensal']:,.2f}")
    print(f"Pool MLM mensal: ${metricas['pool_mlm_mensal']:,.2f}")
    print(f"LAI: ${CENARIO_ATIVO['lai_mensal']}/mês")
    print()
    print("DISTRIBUIÇÃO DO POOL MLM:")
    for nivel, valor in metricas['pool_por_nivel'].items():
        print(f"  Nível {nivel}: ${valor:,.2f}")
    print()
    print("Para executar a simulação, rode:")
    print("python ideepx_simulador_configuravel.py")
